## Test environments
* local Ubuntu 18.04
* remote Ubuntu 16.04 on travis-ci:
  * R 3.6.1 (stable release)
  * R 4.0.0 (under development)
* local macOS install: R 3.6.1
* Windows (on appveyor and winbuilder): R 3.6.1

## R CMD check results
* There were no ERRORs.
* There were no WARNINGs.
* There was 1 NOTE:
  * checking CRAN incoming feasibility ... NOTE
      Maintainer: ‘Jeremy Coyle <jeremyrcoyle@gmail.com>’
      New submission

## Downstream dependencies
* There are no known downstream dependencies.
* This is a new CRAN submission.
